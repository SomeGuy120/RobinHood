﻿using System.Reflection;
using System.Runtime.InteropServices;
[assembly: AssemblyTitle("BraveHaxvius")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Shalzuth")]
[assembly: AssemblyProduct("BraveHaxvius")]
[assembly: AssemblyCopyright("Copyright © 2017 Shalzuth")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
