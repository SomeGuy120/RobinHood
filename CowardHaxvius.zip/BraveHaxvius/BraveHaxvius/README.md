This project is the core of the game.
