﻿using System;

namespace BraveHaxvius.Data
{
    public class News
    {
        public String Id { get; set; }
        public String Type { get; set; }
        public String Translation { get; set; }
        public String Link { get; set; }
    }
}
