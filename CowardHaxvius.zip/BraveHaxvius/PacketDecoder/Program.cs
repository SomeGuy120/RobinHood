﻿using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;

namespace PacketDecoder
{
    public class Program
    {
        [STAThread]
        public static void Main()
        {
            App.Main();
        }
    }
}