﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using BraveHaxvius;
using BraveHaxvius.Data;

namespace Testing
{
    class Program
    {
        static void Main(string[] args)
        {
            var fb = new Facebook();
            fb.Login("francisharcourt33312@gmail.com", "SomeGuyQ333");
            if (fb.TwoFactorAuth)
                fb.FinishTwoFactorAuth("1234 5678");
            fb.AllowFFBE();
            var b = new BraveExvius
            {
                FacebookUserId = fb.Id,
                FacebookToken = fb.AccessToken,
            };
            b.Login();
            b.DoMission(Mission.ImperialInfiltrationELT, false, "20:" + Item.MAXManipleRaidCoin + ":5000");
            b.DoMission(Mission.AirshipDeck);
            b.DoMission(Mission.AlexandriaCastleADV, false, "22:" + Equipment.GenjiGlove.EquipId + ":2");
            b.DoMission(Mission.AirshipDeck);
        }
    }
}
