This is a sample project to use the core dll. To actually login, and communicate with the server.
